package com.example.ui.export

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.FileDownload
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.engine.VynoxExporter
import com.example.model.ExportFps
import com.example.model.ExportQuality
import com.example.model.ExportResolution
import com.example.ui.components.AspectRatioBadge
import com.example.ui.theme.VynoxBlack
import com.example.ui.theme.VynoxBorder
import com.example.ui.theme.VynoxCardSurface
import com.example.ui.theme.VynoxElectricBlue
import com.example.ui.theme.VynoxPurple
import com.example.ui.theme.VynoxTextMuted
import com.example.ui.theme.VynoxTextPrimary
import com.example.ui.theme.VynoxTextSecondary
import com.example.viewmodel.ExportViewModel
import java.util.Locale

@Composable
fun ExportScreen(
    projectId: String,
    viewModel: ExportViewModel,
    onNavigateBack: () -> Unit
) {
    val project by viewModel.project.collectAsState()
    val settings by viewModel.settings.collectAsState()
    val exportState by viewModel.exportState.collectAsState()

    LaunchedEffect(projectId) {
        viewModel.loadProject(projectId)
    }

    BackHandler {
        if (exportState is VynoxExporter.ExportState.Progress) {
            viewModel.cancelExport()
        }
        onNavigateBack()
    }

    val estimatedSize = remember(settings, project) {
        viewModel.calculateEstimatedSizeMb()
    }

    Scaffold(
        containerColor = VynoxBlack,
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .statusBarsPadding()
                    .background(Color(0xFF141320))
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = {
                        if (exportState is VynoxExporter.ExportState.Progress) {
                            viewModel.cancelExport()
                        }
                        onNavigateBack()
                    },
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back to Editor",
                        tint = VynoxTextPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Text(
                    text = "Export Project",
                    color = VynoxTextPrimary,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(18.dp)
        ) {
            // Watermark-Free Guarantee Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color(0xFF065F46), Color(0xFF047857))
                        )
                    )
                    .padding(14.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Verified,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "100% Watermark-Free",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Export clean videos without logos, watermark overlays, or end cards.",
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 11.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Project Info Summary Card
            project?.let { proj ->
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .background(VynoxCardSurface)
                        .border(1.dp, VynoxBorder, RoundedCornerShape(14.dp))
                        .padding(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = proj.name,
                                color = VynoxTextPrimary,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            val sec = proj.totalDurationMs / 1000
                            Text(
                                text = "Duration: ${sec / 60}m ${sec % 60}s • ${proj.videoClips.size} clips",
                                color = VynoxTextMuted,
                                fontSize = 12.sp
                            )
                        }
                        AspectRatioBadge(ratio = proj.aspectRatio)
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Setting 1: Resolution
            Text(
                text = "Resolution",
                color = VynoxTextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExportResolution.values().forEach { res ->
                    val isSelected = settings.resolution == res
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) VynoxPurple.copy(alpha = 0.25f) else VynoxCardSurface)
                            .border(
                                1.5.dp,
                                if (isSelected) VynoxElectricBlue else VynoxBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.setResolution(res) }
                            .padding(vertical = 12.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = res.label.split(" ").first(),
                                color = if (isSelected) VynoxElectricBlue else VynoxTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 14.sp
                            )
                            Text(
                                text = "${res.width}x${res.height}",
                                color = VynoxTextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Setting 2: Frame Rate
            Text(
                text = "Frame Rate (FPS)",
                color = VynoxTextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExportFps.values().forEach { fps ->
                    val isSelected = settings.frameRate == fps
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) VynoxPurple.copy(alpha = 0.25f) else VynoxCardSurface)
                            .border(
                                1.5.dp,
                                if (isSelected) VynoxElectricBlue else VynoxBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.setFrameRate(fps) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${fps.fps} FPS",
                                color = if (isSelected) VynoxElectricBlue else VynoxTextPrimary,
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                            Text(
                                text = fps.label.split(" ").getOrNull(2) ?: "",
                                color = VynoxTextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Setting 3: Quality
            Text(
                text = "Bitrate Quality",
                color = VynoxTextPrimary,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ExportQuality.values().forEach { quality ->
                    val isSelected = settings.quality == quality
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .background(if (isSelected) VynoxPurple.copy(alpha = 0.25f) else VynoxCardSurface)
                            .border(
                                1.5.dp,
                                if (isSelected) VynoxElectricBlue else VynoxBorder,
                                RoundedCornerShape(10.dp)
                            )
                            .clickable { viewModel.setQuality(quality) }
                            .padding(vertical = 10.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = quality.label.split(" ").first(),
                            color = if (isSelected) VynoxElectricBlue else VynoxTextPrimary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // File Size Estimate Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF191826), RoundedCornerShape(10.dp))
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Estimated File Size",
                    color = VynoxTextSecondary,
                    fontSize = 13.sp
                )
                Text(
                    text = "~${String.format(Locale.US, "%.1f", estimatedSize)} MB",
                    color = VynoxElectricBlue,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Export States & Primary Action
            when (val state = exportState) {
                is VynoxExporter.ExportState.Idle, is VynoxExporter.ExportState.Cancelled -> {
                    Button(
                        onClick = { viewModel.startExport() },
                        colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .background(
                                Brush.horizontalGradient(listOf(VynoxPurple, VynoxElectricBlue)),
                                RoundedCornerShape(14.dp)
                            )
                            .testTag("start_export_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.FileDownload,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Export Video Now",
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                }

                is VynoxExporter.ExportState.Progress -> {
                    // Export Progress Box
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF1B1A2A))
                            .border(1.dp, VynoxPurple, RoundedCornerShape(14.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = state.description,
                                    color = VynoxTextPrimary,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "${state.percentage}%",
                                    color = VynoxElectricBlue,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            LinearProgressIndicator(
                                progress = { state.percentage / 100f },
                                color = VynoxElectricBlue,
                                trackColor = Color(0xFF28263D),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(8.dp)
                                    .clip(RoundedCornerShape(4.dp))
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Button(
                                onClick = { viewModel.cancelExport() },
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E2C42)),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Cancel Export", color = Color(0xFFF43F5E), fontSize = 13.sp)
                            }
                        }
                    }
                }

                is VynoxExporter.ExportState.Success -> {
                    // Export Success Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .background(Color(0xFF11221E))
                            .border(1.dp, Color(0xFF10B981), RoundedCornerShape(16.dp))
                            .padding(18.dp)
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.CheckCircle,
                                contentDescription = null,
                                tint = Color(0xFF10B981),
                                modifier = Modifier.size(48.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Export Completed!",
                                color = Color.White,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Saved in Movies/VynoxStudio • ${state.fileSizeMb} MB",
                                color = VynoxTextSecondary,
                                fontSize = 12.sp
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                Button(
                                    onClick = { viewModel.openVideo(state.outputUri) },
                                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF10B981)),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.OpenInNew, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Open Video")
                                }

                                Button(
                                    onClick = { viewModel.shareVideo(state.outputUri) },
                                    colors = ButtonDefaults.buttonColors(containerColor = VynoxPurple),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Share Video")
                                }
                            }
                        }
                    }
                }

                is VynoxExporter.ExportState.Error -> {
                    // Error Card
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color(0xFF2C1318))
                            .border(1.dp, Color(0xFFF43F5E), RoundedCornerShape(14.dp))
                            .padding(16.dp)
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Error, contentDescription = null, tint = Color(0xFFF43F5E))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Export Failed", color = Color(0xFFF43F5E), fontWeight = FontWeight.Bold)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(state.message, color = VynoxTextSecondary, fontSize = 12.sp)
                            Spacer(modifier = Modifier.height(12.dp))
                            Button(
                                onClick = { viewModel.startExport() },
                                colors = ButtonDefaults.buttonColors(containerColor = VynoxPurple),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Text("Retry Export")
                            }
                        }
                    }
                }
            }
        }
    }
}
