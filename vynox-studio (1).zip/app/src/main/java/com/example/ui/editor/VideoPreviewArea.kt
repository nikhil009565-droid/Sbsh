package com.example.ui.editor

import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.FitScreen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Replay10
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.CanvasFitMode
import com.example.model.FilterEffect
import com.example.model.VynoxProject
import com.example.ui.theme.VynoxBorder
import com.example.ui.theme.VynoxElectricBlue
import com.example.ui.theme.VynoxPurple
import com.example.ui.theme.VynoxTextMuted
import com.example.ui.theme.VynoxTextPrimary
import com.example.ui.theme.VynoxTextSecondary
import java.util.Locale

@Composable
fun VideoPreviewArea(
    project: VynoxProject,
    playheadMs: Long,
    isPlaying: Boolean,
    onPlayPause: () -> Unit,
    onSeek: (Long) -> Unit,
    onStep: (Long) -> Unit,
    modifier: Modifier = Modifier
) {
    val totalDurationMs = project.totalDurationMs
    val currentClipPair = remember(project, playheadMs) {
        project.findClipAtTimeline(playheadMs)
    }
    val currentClip = currentClipPair?.second

    val formattedCurrent = remember(playheadMs) { formatTimestamp(playheadMs) }
    val formattedTotal = remember(totalDurationMs) { formatTimestamp(totalDurationMs) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF0C0B12))
            .padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Preview Screen with exact Aspect Ratio
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f, fill = false)
                .height(240.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(project.canvasBgColorHex))
                .border(1.dp, VynoxBorder, RoundedCornerShape(12.dp)),
            contentAlignment = Alignment.Center
        ) {
            // Aspect ratio frame
            BoxWithConstraints(
                modifier = Modifier
                    .aspectRatio(project.aspectRatio.ratio, matchHeightConstraintsFirst = true)
                    .fillMaxHeight()
                    .background(Color(project.canvasBgColorHex)),
                contentAlignment = Alignment.Center
            ) {
                val boxWidth = maxWidth
                val boxHeight = maxHeight

                // Media Frame
                if (currentClip != null) {
                    val scaleFactorX = if (currentClip.flipH) -1f else 1f
                    val scaleFactorY = if (currentClip.flipV) -1f else 1f

                    val colorFilter = remember(currentClip.filterEffect) {
                        when (currentClip.filterEffect) {
                            FilterEffect.NOIR -> ColorFilter.colorMatrix(
                                androidx.compose.ui.graphics.ColorMatrix().apply { setToSaturation(0f) }
                            )
                            FilterEffect.WARM -> ColorFilter.tint(Color(0xFFFFB74D).copy(alpha = 0.25f))
                            FilterEffect.COOL -> ColorFilter.tint(Color(0xFF00D2FF).copy(alpha = 0.25f))
                            FilterEffect.CYBERPUNK -> ColorFilter.tint(Color(0xFFE040FB).copy(alpha = 0.3f))
                            FilterEffect.VINTAGE -> ColorFilter.tint(Color(0xFFD7CCC8).copy(alpha = 0.35f))
                            else -> null
                        }
                    }

                    AsyncImage(
                        model = currentClip.uri,
                        contentDescription = "Preview frame",
                        contentScale = if (project.fitMode == CanvasFitMode.FILL) ContentScale.Crop else ContentScale.Fit,
                        colorFilter = colorFilter,
                        modifier = Modifier
                            .fillMaxSize()
                            .rotate(currentClip.rotationDegrees.toFloat())
                            .scale(scaleFactorX, scaleFactorY)
                    )
                } else {
                    // Empty Timeline placeholder
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Text(
                            text = "Add Media to Timeline",
                            color = VynoxTextMuted,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                // Text Overlays
                project.textOverlays.forEach { textOverlay ->
                    if (playheadMs in textOverlay.startTimelineMs..textOverlay.endTimelineMs) {
                        val xOffset = boxWidth * (textOverlay.xPercent - 0.5f)
                        val yOffset = boxHeight * (textOverlay.yPercent - 0.5f)

                        Box(
                            modifier = Modifier
                                .offset { IntOffset(xOffset.roundToPx(), yOffset.roundToPx()) }
                                .then(
                                    if (textOverlay.hasBackground) Modifier.background(
                                        Color(textOverlay.bgColorHex),
                                        RoundedCornerShape(4.dp)
                                    ).padding(horizontal = 6.dp, vertical = 2.dp)
                                    else Modifier
                                )
                        ) {
                            Text(
                                text = textOverlay.text,
                                color = Color(textOverlay.textColorHex),
                                fontSize = textOverlay.fontSizeSp.sp,
                                fontWeight = FontWeight.Bold,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }

                // Image Overlays
                project.imageOverlays.forEach { imgOverlay ->
                    if (playheadMs in imgOverlay.startTimelineMs..imgOverlay.endTimelineMs) {
                        val xOffset = boxWidth * (imgOverlay.xPercent - 0.5f)
                        val yOffset = boxHeight * (imgOverlay.yPercent - 0.5f)

                        Box(
                            modifier = Modifier
                                .offset { IntOffset(xOffset.roundToPx(), yOffset.roundToPx()) }
                                .size((64 * imgOverlay.scale).dp)
                                .rotate(imgOverlay.rotation)
                        ) {
                            AsyncImage(
                                model = imgOverlay.uri,
                                contentDescription = "Overlay sticker",
                                contentScale = ContentScale.Fit,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(4.dp))

        // Progress Slider
        Slider(
            value = playheadMs.toFloat().coerceIn(0f, totalDurationMs.toFloat()),
            onValueChange = { onSeek(it.toLong()) },
            valueRange = 0f..totalDurationMs.toFloat().coerceAtLeast(1000f),
            colors = SliderDefaults.colors(
                thumbColor = VynoxElectricBlue,
                activeTrackColor = VynoxPurple,
                inactiveTrackColor = Color(0xFF222033)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(24.dp)
                .testTag("preview_scrub_slider")
        )

        // Player Controls Row
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Current / Total Time
            Text(
                text = "$formattedCurrent / $formattedTotal",
                color = VynoxTextPrimary,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )

            // Playback buttons
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Step back 1s
                IconButton(
                    onClick = { onStep(-1000L) },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FastRewind,
                        contentDescription = "Step backward 1s",
                        tint = VynoxTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Play / Pause
                IconButton(
                    onClick = onPlayPause,
                    modifier = Modifier
                        .size(42.dp)
                        .background(VynoxPurple, CircleShape)
                        .testTag("play_pause_button")
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                        contentDescription = if (isPlaying) "Pause" else "Play",
                        tint = Color.White,
                        modifier = Modifier.size(24.dp)
                    )
                }

                Spacer(modifier = Modifier.width(4.dp))

                // Step forward 1s
                IconButton(
                    onClick = { onStep(1000L) },
                    modifier = Modifier.size(34.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.FastForward,
                        contentDescription = "Step forward 1s",
                        tint = VynoxTextSecondary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            // Aspect ratio pill
            Box(
                modifier = Modifier
                    .background(Color(0xFF1B1A28), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Text(
                    text = project.aspectRatio.label.split(" ").first(),
                    color = VynoxElectricBlue,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
    }
}

private fun formatTimestamp(ms: Long): String {
    val totalSeconds = ms / 1000
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    val hundredths = (ms % 1000) / 100
    return String.format(Locale.US, "%02d:%02d.%01d", minutes, seconds, hundredths)
}
