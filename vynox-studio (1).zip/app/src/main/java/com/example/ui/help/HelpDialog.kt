package com.example.ui.help

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.VynoxBorder
import com.example.ui.theme.VynoxElectricBlue
import com.example.ui.theme.VynoxPurple
import com.example.ui.theme.VynoxTextMuted
import com.example.ui.theme.VynoxTextPrimary
import com.example.ui.theme.VynoxTextSecondary

@Composable
fun HelpDialog(onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF161522))
                .border(1.dp, VynoxBorder, RoundedCornerShape(20.dp))
                .padding(20.dp)
                .testTag("help_dialog")
        ) {
            Column(modifier = Modifier.verticalScroll(rememberScrollState())) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.HelpOutline,
                            contentDescription = null,
                            tint = VynoxElectricBlue,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Editor Guide",
                            color = VynoxTextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = VynoxTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                HelpItem(
                    title = "Trimming & Splitting",
                    description = "Select any clip on the timeline to reveal the yellow trim handles. Drag the start or end handle to adjust length. Tap 'Split' to cut the clip right at the current playhead position."
                )

                HelpItem(
                    title = "Transitions",
                    description = "Tap the 'Transitions' tool in the bottom bar to apply cinematic transitions (Fade, Dissolve, Slide, Zoom, Wipe) between adjacent video clips."
                )

                HelpItem(
                    title = "Audio & Voice-over",
                    description = "Tap 'Audio' to import custom music tracks or record live voice-over commentary directly from your microphone into the secondary audio track."
                )

                HelpItem(
                    title = "Text, Fonts & Animations",
                    description = "Add customizable text with outlines, glow, and animations (Fade, Slide Up, Zoom). Supports Hindi and English typography."
                )

                HelpItem(
                    title = "Color Grading & Filters",
                    description = "Choose from preset filters (Vibrant, Cinematic, Noir, Cyberpunk) or fine-tune Brightness, Contrast, Saturation, Temperature, and Vignette."
                )

                HelpItem(
                    title = "Watermark-Free Export",
                    description = "Tap Export at the top right to render your completed video in 480p, 720p, or 1080p Full HD with zero watermarks or ads."
                )
            }
        }
    }
}

@Composable
private fun HelpItem(title: String, description: String) {
    Column(modifier = Modifier.padding(vertical = 8.dp)) {
        Text(
            text = title,
            color = VynoxElectricBlue,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold
        )
        Spacer(modifier = Modifier.height(3.dp))
        Text(
            text = description,
            color = VynoxTextSecondary,
            fontSize = 12.sp,
            lineHeight = 17.sp
        )
    }
}
