package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ProjectRepository
import com.example.engine.VynoxMediaHelper
import com.example.model.AspectRatio
import com.example.model.AudioClip
import com.example.model.CanvasFitMode
import com.example.model.ClipTransition
import com.example.model.ColorAdjustments
import com.example.model.FilterEffect
import com.example.model.ImageOverlay
import com.example.model.TextAnimation
import com.example.model.TextOverlay
import com.example.model.TransitionType
import com.example.model.VideoClip
import com.example.model.VynoxProject
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.File
import java.util.UUID

enum class EditorTab(val label: String) {
    MEDIA("Media"),
    AUDIO("Audio"),
    TEXT("Text"),
    EFFECTS("Effects"),
    TRANSITIONS("Transitions"),
    CANVAS("Canvas"),
    ADJUST("Adjust"),
    SPEED("Speed"),
    LAYERS("Layers")
}

class EditorViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = ProjectRepository(application)
    private val voiceRecorder = VynoxMediaHelper.VoiceRecorder(application)

    private val _project = MutableStateFlow<VynoxProject?>(null)
    val project: StateFlow<VynoxProject?> = _project.asStateFlow()

    private val _playheadPositionMs = MutableStateFlow(0L)
    val playheadPositionMs: StateFlow<Long> = _playheadPositionMs.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _activeTab = MutableStateFlow<EditorTab?>(null)
    val activeTab: StateFlow<EditorTab?> = _activeTab.asStateFlow()

    private val _selectedClipIndex = MutableStateFlow<Int?>(null)
    val selectedClipIndex: StateFlow<Int?> = _selectedClipIndex.asStateFlow()

    private val _selectedTextId = MutableStateFlow<String?>(null)
    val selectedTextId: StateFlow<String?> = _selectedTextId.asStateFlow()

    private val _timelineZoom = MutableStateFlow(1.0f)
    val timelineZoom: StateFlow<Float> = _timelineZoom.asStateFlow()

    private val _isRecordingVoice = MutableStateFlow(false)
    val isRecordingVoice: StateFlow<Boolean> = _isRecordingVoice.asStateFlow()

    private val _saveMessage = MutableStateFlow<String?>(null)
    val saveMessage: StateFlow<String?> = _saveMessage.asStateFlow()

    // Undo / Redo Stacks
    private val undoStack = mutableListOf<VynoxProject>()
    private val redoStack = mutableListOf<VynoxProject>()

    private val _canUndo = MutableStateFlow(false)
    val canUndo: StateFlow<Boolean> = _canUndo.asStateFlow()

    private val _canRedo = MutableStateFlow(false)
    val canRedo: StateFlow<Boolean> = _canRedo.asStateFlow()

    private var playbackJob: Job? = null

    fun loadProject(projectId: String) {
        viewModelScope.launch {
            val loaded = repository.getProject(projectId)
            if (loaded != null) {
                _project.value = loaded
                _selectedClipIndex.value = if (loaded.videoClips.isNotEmpty()) 0 else null
                _playheadPositionMs.value = 0L
                undoStack.clear()
                redoStack.clear()
                updateUndoRedoStates()
            }
        }
    }

    private fun pushUndoState() {
        val curr = _project.value ?: return
        undoStack.add(curr)
        if (undoStack.size > 25) {
            undoStack.removeAt(0)
        }
        redoStack.clear()
        updateUndoRedoStates()
    }

    private fun updateUndoRedoStates() {
        _canUndo.value = undoStack.isNotEmpty()
        _canRedo.value = redoStack.isNotEmpty()
    }

    fun undo() {
        val curr = _project.value ?: return
        if (undoStack.isNotEmpty()) {
            redoStack.add(curr)
            val prev = undoStack.removeAt(undoStack.lastIndex)
            _project.value = prev
            updateUndoRedoStates()
            autoSave()
        }
    }

    fun redo() {
        val curr = _project.value ?: return
        if (redoStack.isNotEmpty()) {
            undoStack.add(curr)
            val next = redoStack.removeAt(redoStack.lastIndex)
            _project.value = next
            updateUndoRedoStates()
            autoSave()
        }
    }

    fun setActiveTab(tab: EditorTab?) {
        _activeTab.value = if (_activeTab.value == tab) null else tab
    }

    fun selectClip(index: Int?) {
        _selectedClipIndex.value = index
        _selectedTextId.value = null
    }

    fun selectText(id: String?) {
        _selectedTextId.value = id
        _selectedClipIndex.value = null
    }

    fun setTimelineZoom(zoom: Float) {
        _timelineZoom.value = zoom.coerceIn(0.5f, 3.0f)
    }

    fun seekTo(positionMs: Long) {
        val total = _project.value?.totalDurationMs ?: 1000L
        val clamped = positionMs.coerceIn(0L, total)
        _playheadPositionMs.value = clamped
    }

    fun stepFrame(deltaMs: Long) {
        seekTo(_playheadPositionMs.value + deltaMs)
    }

    fun togglePlayPause() {
        if (_isPlaying.value) {
            pause()
        } else {
            play()
        }
    }

    fun play() {
        val total = _project.value?.totalDurationMs ?: 1000L
        if (_playheadPositionMs.value >= total) {
            _playheadPositionMs.value = 0L
        }
        _isPlaying.value = true
        playbackJob?.cancel()
        playbackJob = viewModelScope.launch {
            val interval = 33L // ~30 FPS preview tick
            while (isActive && _isPlaying.value) {
                delay(interval)
                val next = _playheadPositionMs.value + interval
                if (next >= total) {
                    _playheadPositionMs.value = total
                    _isPlaying.value = false
                    break
                } else {
                    _playheadPositionMs.value = next
                }
            }
        }
    }

    fun pause() {
        _isPlaying.value = false
        playbackJob?.cancel()
    }

    // --- Clip Editing Actions ---
    fun trimClip(clipIndex: Int, newStartMs: Long, newEndMs: Long) {
        val curr = _project.value ?: return
        if (clipIndex !in curr.videoClips.indices) return
        pushUndoState()

        val clip = curr.videoClips[clipIndex]
        val clampedStart = newStartMs.coerceIn(0L, clip.sourceDurationMs - 100L)
        val clampedEnd = newEndMs.coerceIn(clampedStart + 100L, clip.sourceDurationMs)
        val updatedClips = curr.videoClips.toMutableList()
        updatedClips[clipIndex] = clip.copy(trimStartMs = clampedStart, trimEndMs = clampedEnd)

        _project.value = curr.copy(videoClips = updatedClips)
        autoSave()
    }

    fun splitClipAtPlayhead() {
        val curr = _project.value ?: return
        val currentPlayhead = _playheadPositionMs.value
        val pair = curr.findClipAtTimeline(currentPlayhead) ?: return
        val clipIndex = pair.first
        val clip = pair.second

        val clipOffset = curr.getClipStartOffset(clipIndex)
        val localOffset = currentPlayhead - clipOffset
        val localMediaTimeMs = (clip.trimStartMs + (localOffset * clip.speed)).toLong()

        if (localMediaTimeMs <= clip.trimStartMs + 200L || localMediaTimeMs >= clip.trimEndMs - 200L) {
            return // Too close to boundaries
        }

        pushUndoState()
        val firstClip = clip.copy(
            id = UUID.randomUUID().toString(),
            name = "${clip.name} (Part 1)",
            trimEndMs = localMediaTimeMs
        )
        val secondClip = clip.copy(
            id = UUID.randomUUID().toString(),
            name = "${clip.name} (Part 2)",
            trimStartMs = localMediaTimeMs
        )

        val updatedClips = curr.videoClips.toMutableList()
        updatedClips.removeAt(clipIndex)
        updatedClips.add(clipIndex, firstClip)
        updatedClips.add(clipIndex + 1, secondClip)

        _project.value = curr.copy(videoClips = updatedClips)
        _selectedClipIndex.value = clipIndex
        autoSave()
    }

    fun deleteClip(index: Int) {
        val curr = _project.value ?: return
        if (index !in curr.videoClips.indices) return
        pushUndoState()

        val updatedClips = curr.videoClips.toMutableList()
        updatedClips.removeAt(index)

        _project.value = curr.copy(videoClips = updatedClips)
        _selectedClipIndex.value = if (updatedClips.isNotEmpty()) index.coerceAtMost(updatedClips.lastIndex) else null
        autoSave()
    }

    fun duplicateClip(index: Int) {
        val curr = _project.value ?: return
        if (index !in curr.videoClips.indices) return
        pushUndoState()

        val clip = curr.videoClips[index]
        val dup = clip.copy(
            id = UUID.randomUUID().toString(),
            name = "${clip.name} (Copy)"
        )

        val updatedClips = curr.videoClips.toMutableList()
        updatedClips.add(index + 1, dup)

        _project.value = curr.copy(videoClips = updatedClips)
        _selectedClipIndex.value = index + 1
        autoSave()
    }

    fun reorderClip(fromIndex: Int, toIndex: Int) {
        val curr = _project.value ?: return
        if (fromIndex !in curr.videoClips.indices || toIndex !in curr.videoClips.indices) return
        pushUndoState()

        val updatedClips = curr.videoClips.toMutableList()
        val item = updatedClips.removeAt(fromIndex)
        updatedClips.add(toIndex, item)

        _project.value = curr.copy(videoClips = updatedClips)
        _selectedClipIndex.value = toIndex
        autoSave()
    }

    fun setClipSpeed(index: Int, speed: Float) {
        val curr = _project.value ?: return
        if (index !in curr.videoClips.indices) return
        pushUndoState()

        val updatedClips = curr.videoClips.toMutableList()
        updatedClips[index] = updatedClips[index].copy(speed = speed.coerceIn(0.25f, 4.0f))

        _project.value = curr.copy(videoClips = updatedClips)
        autoSave()
    }

    fun setClipVolume(index: Int, volume: Float) {
        val curr = _project.value ?: return
        if (index !in curr.videoClips.indices) return
        pushUndoState()

        val updatedClips = curr.videoClips.toMutableList()
        updatedClips[index] = updatedClips[index].copy(volume = volume.coerceIn(0f, 2f))

        _project.value = curr.copy(videoClips = updatedClips)
        autoSave()
    }

    fun rotateClip(index: Int) {
        val curr = _project.value ?: return
        if (index !in curr.videoClips.indices) return
        pushUndoState()

        val clip = curr.videoClips[index]
        val updatedRot = (clip.rotationDegrees + 90) % 360
        val updatedClips = curr.videoClips.toMutableList()
        updatedClips[index] = clip.copy(rotationDegrees = updatedRot)

        _project.value = curr.copy(videoClips = updatedClips)
        autoSave()
    }

    fun flipClipH(index: Int) {
        val curr = _project.value ?: return
        if (index !in curr.videoClips.indices) return
        pushUndoState()

        val clip = curr.videoClips[index]
        val updatedClips = curr.videoClips.toMutableList()
        updatedClips[index] = clip.copy(flipH = !clip.flipH)

        _project.value = curr.copy(videoClips = updatedClips)
        autoSave()
    }

    fun flipClipV(index: Int) {
        val curr = _project.value ?: return
        if (index !in curr.videoClips.indices) return
        pushUndoState()

        val clip = curr.videoClips[index]
        val updatedClips = curr.videoClips.toMutableList()
        updatedClips[index] = clip.copy(flipV = !clip.flipV)

        _project.value = curr.copy(videoClips = updatedClips)
        autoSave()
    }

    fun setClipFilter(index: Int, filter: FilterEffect) {
        val curr = _project.value ?: return
        if (index !in curr.videoClips.indices) return
        pushUndoState()

        val updatedClips = curr.videoClips.toMutableList()
        updatedClips[index] = updatedClips[index].copy(filterEffect = filter)

        _project.value = curr.copy(videoClips = updatedClips)
        autoSave()
    }

    fun setClipOpacity(index: Int, opacity: Float) {
        val curr = _project.value ?: return
        if (index !in curr.videoClips.indices) return
        pushUndoState()

        val updatedClips = curr.videoClips.toMutableList()
        updatedClips[index] = updatedClips[index].copy(opacity = opacity.coerceIn(0f, 1f))

        _project.value = curr.copy(videoClips = updatedClips)
        autoSave()
    }

    fun addClips(uris: List<Uri>) {
        viewModelScope.launch {
            val curr = _project.value ?: return@launch
            pushUndoState()

            val newClips = mutableListOf<VideoClip>()
            for ((idx, uri) in uris.withIndex()) {
                val mediaInfo = VynoxMediaHelper.inspectMedia(getApplication(), uri)
                newClips.add(
                    VideoClip(
                        id = UUID.randomUUID().toString(),
                        uri = uri.toString(),
                        name = "Clip ${curr.videoClips.size + idx + 1}",
                        isImage = !mediaInfo.isVideo,
                        sourceDurationMs = mediaInfo.durationMs,
                        trimStartMs = 0L,
                        trimEndMs = mediaInfo.durationMs
                    )
                )
            }

            _project.value = curr.copy(videoClips = curr.videoClips + newClips)
            autoSave()
        }
    }

    // --- Audio Actions ---
    fun addAudioClip(uri: Uri, title: String) {
        viewModelScope.launch {
            val curr = _project.value ?: return@launch
            pushUndoState()

            val mediaInfo = VynoxMediaHelper.inspectMedia(getApplication(), uri)
            val audioClip = AudioClip(
                id = UUID.randomUUID().toString(),
                uri = uri.toString(),
                title = title.ifBlank { "Audio Track" },
                startTimelineMs = _playheadPositionMs.value,
                durationMs = mediaInfo.durationMs.coerceAtLeast(3000L),
                volume = 1.0f
            )

            _project.value = curr.copy(audioClips = curr.audioClips + audioClip)
            autoSave()
        }
    }

    fun startVoiceRecording(): Boolean {
        val success = voiceRecorder.startRecording()
        _isRecordingVoice.value = success
        return success
    }

    fun stopVoiceRecording() {
        val file = voiceRecorder.stopRecording()
        _isRecordingVoice.value = false
        if (file != null && file.exists() && file.length() > 0) {
            val curr = _project.value ?: return
            pushUndoState()

            val voiceClip = AudioClip(
                id = UUID.randomUUID().toString(),
                uri = Uri.fromFile(file).toString(),
                title = "Voice-over",
                startTimelineMs = _playheadPositionMs.value,
                durationMs = 4000L,
                volume = 1.2f,
                isVoiceOver = true
            )

            _project.value = curr.copy(audioClips = curr.audioClips + voiceClip)
            autoSave()
        }
    }

    fun deleteAudioClip(id: String) {
        val curr = _project.value ?: return
        pushUndoState()
        _project.value = curr.copy(audioClips = curr.audioClips.filter { it.id != id })
        autoSave()
    }

    fun updateAudioVolume(id: String, volume: Float) {
        val curr = _project.value ?: return
        pushUndoState()
        val updated = curr.audioClips.map {
            if (it.id == id) it.copy(volume = volume.coerceIn(0f, 2f)) else it
        }
        _project.value = curr.copy(audioClips = updated)
        autoSave()
    }

    // --- Text Actions ---
    fun addTextOverlay(
        text: String = "Vynox Text",
        colorHex: Long = 0xFFFFFFFF,
        fontSizeSp: Float = 26f,
        hasOutline: Boolean = true,
        animation: TextAnimation = TextAnimation.NONE
    ) {
        val curr = _project.value ?: return
        pushUndoState()

        val start = _playheadPositionMs.value
        val end = (start + 3500L).coerceAtMost(curr.totalDurationMs.coerceAtLeast(start + 1000L))

        val textOverlay = TextOverlay(
            id = UUID.randomUUID().toString(),
            text = text,
            textColorHex = colorHex,
            fontSizeSp = fontSizeSp,
            hasOutline = hasOutline,
            animation = animation,
            startTimelineMs = start,
            endTimelineMs = end
        )

        _project.value = curr.copy(textOverlays = curr.textOverlays + textOverlay)
        _selectedTextId.value = textOverlay.id
        autoSave()
    }

    fun updateTextOverlay(overlay: TextOverlay) {
        val curr = _project.value ?: return
        pushUndoState()
        val updated = curr.textOverlays.map { if (it.id == overlay.id) overlay else it }
        _project.value = curr.copy(textOverlays = updated)
        autoSave()
    }

    fun deleteTextOverlay(id: String) {
        val curr = _project.value ?: return
        pushUndoState()
        _project.value = curr.copy(textOverlays = curr.textOverlays.filter { it.id != id })
        if (_selectedTextId.value == id) _selectedTextId.value = null
        autoSave()
    }

    // --- Image / Sticker Overlay Actions ---
    fun addImageOverlay(uri: Uri) {
        val curr = _project.value ?: return
        pushUndoState()

        val start = _playheadPositionMs.value
        val end = (start + 4000L).coerceAtMost(curr.totalDurationMs.coerceAtLeast(start + 1000L))

        val imgOverlay = ImageOverlay(
            id = UUID.randomUUID().toString(),
            uri = uri.toString(),
            startTimelineMs = start,
            endTimelineMs = end
        )

        _project.value = curr.copy(imageOverlays = curr.imageOverlays + imgOverlay)
        autoSave()
    }

    fun deleteImageOverlay(id: String) {
        val curr = _project.value ?: return
        pushUndoState()
        _project.value = curr.copy(imageOverlays = curr.imageOverlays.filter { it.id != id })
        autoSave()
    }

    // --- Transitions ---
    fun setTransition(clipIndex: Int, type: TransitionType) {
        val curr = _project.value ?: return
        pushUndoState()

        val updatedTransitions = curr.transitions.filter { it.clipIndex != clipIndex }.toMutableList()
        if (type != TransitionType.NONE) {
            updatedTransitions.add(ClipTransition(clipIndex = clipIndex, type = type))
        }

        _project.value = curr.copy(transitions = updatedTransitions)
        autoSave()
    }

    // --- Canvas Actions ---
    fun setAspectRatio(ratio: AspectRatio) {
        val curr = _project.value ?: return
        pushUndoState()
        _project.value = curr.copy(aspectRatio = ratio)
        autoSave()
    }

    fun setCanvasBgColor(colorHex: Long) {
        val curr = _project.value ?: return
        pushUndoState()
        _project.value = curr.copy(canvasBgColorHex = colorHex)
        autoSave()
    }

    fun setCanvasBlurBg(enabled: Boolean) {
        val curr = _project.value ?: return
        pushUndoState()
        _project.value = curr.copy(canvasBlurBg = enabled)
        autoSave()
    }

    fun setCanvasFitMode(mode: CanvasFitMode) {
        val curr = _project.value ?: return
        pushUndoState()
        _project.value = curr.copy(fitMode = mode)
        autoSave()
    }

    // --- Adjustments ---
    fun updateAdjustments(adj: ColorAdjustments) {
        val curr = _project.value ?: return
        pushUndoState()
        _project.value = curr.copy(colorAdjustments = adj)
        autoSave()
    }

    fun resetAdjustments() {
        val curr = _project.value ?: return
        pushUndoState()
        _project.value = curr.copy(colorAdjustments = ColorAdjustments())
        autoSave()
    }

    // --- Project Meta & Saving ---
    fun renameProject(name: String) {
        val curr = _project.value ?: return
        _project.value = curr.copy(name = name.ifBlank { "Vynox Project" })
        autoSave()
    }

    fun saveProjectManually() {
        val curr = _project.value ?: return
        viewModelScope.launch {
            repository.saveProject(curr)
            _saveMessage.value = "Project saved successfully"
            delay(2000)
            _saveMessage.value = null
        }
    }

    private fun autoSave() {
        val curr = _project.value ?: return
        viewModelScope.launch {
            repository.saveProject(curr)
        }
    }

    override fun onCleared() {
        super.onCleared()
        playbackJob?.cancel()
        voiceRecorder.stopRecording()
    }
}
