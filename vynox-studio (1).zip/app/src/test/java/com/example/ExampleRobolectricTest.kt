package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ProjectRepository
import com.example.model.AspectRatio
import com.example.model.FilterEffect
import com.example.model.TextAnimation
import com.example.model.TextOverlay
import com.example.model.VideoClip
import com.example.model.VynoxProject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.util.UUID

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context matches Vynox Studio`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Vynox Studio", appName)
    }

    @Test
    fun `video clip duration calculation accounts for speed and trim`() {
        val clip = VideoClip(
            uri = "content://media/external/video/1",
            sourceDurationMs = 10000L,
            trimStartMs = 2000L,
            trimEndMs = 8000L,
            speed = 2.0f
        )
        // Trim length: 8000 - 2000 = 6000ms. At 2x speed: 3000ms
        assertEquals(3000L, clip.durationMs)
    }

    @Test
    fun `project serialization and deserialization roundtrip preserves timeline data`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val repository = ProjectRepository(context)

        val clip1 = VideoClip(
            id = UUID.randomUUID().toString(),
            uri = "file:///dummy/video1.mp4",
            name = "Scene 1",
            sourceDurationMs = 6000L,
            trimStartMs = 1000L,
            trimEndMs = 5000L,
            speed = 1.0f,
            filterEffect = FilterEffect.CINEMATIC
        )

        val text = TextOverlay(
            id = UUID.randomUUID().toString(),
            text = "Vynox Studio Opening",
            fontSizeSp = 32f,
            animation = TextAnimation.ZOOM,
            startTimelineMs = 500L,
            endTimelineMs = 3500L
        )

        val originalProject = VynoxProject(
            id = "test-project-123",
            name = "Action Trailer",
            aspectRatio = AspectRatio.RATIO_9_16,
            videoClips = listOf(clip1),
            textOverlays = listOf(text)
        )

        val json = repository.serializeProject(originalProject)
        assertNotNull(json)
        assertTrue(json.contains("Action Trailer"))

        val deserialized = repository.deserializeProject(json)
        assertNotNull(deserialized)
        assertEquals(originalProject.id, deserialized?.id)
        assertEquals(originalProject.name, deserialized?.name)
        assertEquals(originalProject.aspectRatio, deserialized?.aspectRatio)
        assertEquals(1, deserialized?.videoClips?.size)
        assertEquals("Scene 1", deserialized?.videoClips?.first()?.name)
        assertEquals(FilterEffect.CINEMATIC, deserialized?.videoClips?.first()?.filterEffect)
        assertEquals(1, deserialized?.textOverlays?.size)
        assertEquals("Vynox Studio Opening", deserialized?.textOverlays?.first()?.text)
    }
}
