package com.example.ui.editor

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Animation
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Flip
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.RotateRight
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.TextFields
import androidx.compose.material.icons.filled.Transform
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AspectRatio
import com.example.model.CanvasFitMode
import com.example.model.ColorAdjustments
import com.example.model.FilterEffect
import com.example.model.TextAnimation
import com.example.model.TransitionType
import com.example.ui.theme.VynoxBorder
import com.example.ui.theme.VynoxCardSurface
import com.example.ui.theme.VynoxElectricBlue
import com.example.ui.theme.VynoxPurple
import com.example.ui.theme.VynoxPurpleGlow
import com.example.ui.theme.VynoxTextMuted
import com.example.ui.theme.VynoxTextPrimary
import com.example.ui.theme.VynoxTextSecondary
import com.example.viewmodel.EditorTab
import com.example.viewmodel.EditorViewModel

@Composable
fun EditorToolbars(
    viewModel: EditorViewModel,
    modifier: Modifier = Modifier
) {
    val activeTab by viewModel.activeTab.collectAsState(null)
    val selectedClipIndex by viewModel.selectedClipIndex.collectAsState(null)
    val project by viewModel.project.collectAsState(null)
    val isRecordingVoice by viewModel.isRecordingVoice.collectAsState(false)

    // Media Picker launcher for adding clips
    val addClipsPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia()
    ) { uris: List<Uri> ->
        if (uris.isNotEmpty()) {
            viewModel.addClips(uris)
        }
    }

    // Audio Picker launcher
    val addAudioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.addAudioClip(uri, "Music Track")
        }
    }

    // Image sticker picker
    val addStickerPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            viewModel.addImageOverlay(uri)
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(Color(0xFF13121E))
            .border(1.dp, VynoxBorder)
    ) {
        // Expandable Active Tool Sub-Panel
        if (activeTab != null) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(Color(0xFF181726))
                    .padding(12.dp)
            ) {
                when (activeTab) {
                    EditorTab.MEDIA -> MediaPanel(
                        onAddMedia = {
                            addClipsPicker.launch(
                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                            )
                        },
                        onClose = { viewModel.setActiveTab(null) }
                    )
                    EditorTab.AUDIO -> AudioPanel(
                        isRecording = isRecordingVoice,
                        onImportMusic = { addAudioPicker.launch("audio/*") },
                        onStartRecord = { viewModel.startVoiceRecording() },
                        onStopRecord = { viewModel.stopVoiceRecording() },
                        onClose = { viewModel.setActiveTab(null) }
                    )
                    EditorTab.TEXT -> TextPanel(
                        onAddText = { text, color, fontSize, anim ->
                            viewModel.addTextOverlay(
                                text = text,
                                colorHex = color,
                                fontSizeSp = fontSize,
                                animation = anim
                            )
                        },
                        onClose = { viewModel.setActiveTab(null) }
                    )
                    EditorTab.EFFECTS -> EffectsPanel(
                        selectedClipIndex = selectedClipIndex,
                        onSelectFilter = { filter ->
                            selectedClipIndex?.let { viewModel.setClipFilter(it, filter) }
                        },
                        onClose = { viewModel.setActiveTab(null) }
                    )
                    EditorTab.TRANSITIONS -> TransitionsPanel(
                        selectedClipIndex = selectedClipIndex,
                        onSelectTransition = { type ->
                            selectedClipIndex?.let { viewModel.setTransition(it, type) }
                        },
                        onClose = { viewModel.setActiveTab(null) }
                    )
                    EditorTab.CANVAS -> CanvasPanel(
                        currentRatio = project?.aspectRatio ?: AspectRatio.RATIO_9_16,
                        onSelectRatio = { viewModel.setAspectRatio(it) },
                        onSelectBgColor = { viewModel.setCanvasBgColor(it) },
                        onClose = { viewModel.setActiveTab(null) }
                    )
                    EditorTab.ADJUST -> AdjustPanel(
                        adjustments = project?.colorAdjustments ?: ColorAdjustments(),
                        onUpdate = { viewModel.updateAdjustments(it) },
                        onReset = { viewModel.resetAdjustments() },
                        onClose = { viewModel.setActiveTab(null) }
                    )
                    EditorTab.SPEED -> SpeedPanel(
                        selectedClipIndex = selectedClipIndex,
                        currentSpeed = selectedClipIndex?.let { project?.videoClips?.getOrNull(it)?.speed } ?: 1.0f,
                        onSetSpeed = { speed ->
                            selectedClipIndex?.let { viewModel.setClipSpeed(it, speed) }
                        },
                        onClose = { viewModel.setActiveTab(null) }
                    )
                    EditorTab.LAYERS -> LayersPanel(
                        project = project,
                        onClose = { viewModel.setActiveTab(null) }
                    )
                    null -> {}
                }
            }
        }

        // Horizontal Scrollable Primary Toolbar Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 6.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ToolTabItem(
                label = "Media",
                icon = Icons.Default.AddPhotoAlternate,
                isSelected = activeTab == EditorTab.MEDIA,
                onClick = { viewModel.setActiveTab(EditorTab.MEDIA) }
            )
            ToolTabItem(
                label = "Audio",
                icon = Icons.Default.MusicNote,
                isSelected = activeTab == EditorTab.AUDIO,
                onClick = { viewModel.setActiveTab(EditorTab.AUDIO) }
            )
            ToolTabItem(
                label = "Text",
                icon = Icons.Default.TextFields,
                isSelected = activeTab == EditorTab.TEXT,
                onClick = { viewModel.setActiveTab(EditorTab.TEXT) }
            )
            ToolTabItem(
                label = "Stickers",
                icon = Icons.Default.AutoAwesome,
                isSelected = false,
                onClick = {
                    addStickerPicker.launch(
                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                    )
                }
            )
            ToolTabItem(
                label = "Effects",
                icon = Icons.Default.ColorLens,
                isSelected = activeTab == EditorTab.EFFECTS,
                onClick = { viewModel.setActiveTab(EditorTab.EFFECTS) }
            )
            ToolTabItem(
                label = "Transitions",
                icon = Icons.Default.Transform,
                isSelected = activeTab == EditorTab.TRANSITIONS,
                onClick = { viewModel.setActiveTab(EditorTab.TRANSITIONS) }
            )
            ToolTabItem(
                label = "Canvas",
                icon = Icons.Default.AspectRatio,
                isSelected = activeTab == EditorTab.CANVAS,
                onClick = { viewModel.setActiveTab(EditorTab.CANVAS) }
            )
            ToolTabItem(
                label = "Adjust",
                icon = Icons.Default.Tune,
                isSelected = activeTab == EditorTab.ADJUST,
                onClick = { viewModel.setActiveTab(EditorTab.ADJUST) }
            )
            ToolTabItem(
                label = "Speed",
                icon = Icons.Default.Speed,
                isSelected = activeTab == EditorTab.SPEED,
                onClick = { viewModel.setActiveTab(EditorTab.SPEED) }
            )
            ToolTabItem(
                label = "Layers",
                icon = Icons.Default.Layers,
                isSelected = activeTab == EditorTab.LAYERS,
                onClick = { viewModel.setActiveTab(EditorTab.LAYERS) }
            )
            // Quick Transform tools on selected clip
            if (selectedClipIndex != null) {
                ToolTabItem(
                    label = "Rotate",
                    icon = Icons.Default.RotateRight,
                    isSelected = false,
                    onClick = { selectedClipIndex?.let { viewModel.rotateClip(it) } }
                )
                ToolTabItem(
                    label = "Flip",
                    icon = Icons.Default.Flip,
                    isSelected = false,
                    onClick = { selectedClipIndex?.let { viewModel.flipClipH(it) } }
                )
            }
        }
    }
}

@Composable
private fun ToolTabItem(
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (isSelected) VynoxPurple.copy(alpha = 0.25f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) VynoxElectricBlue else VynoxTextSecondary,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = if (isSelected) Color.White else VynoxTextMuted,
            fontSize = 11.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
        )
    }
}

// --- Tool Sub-Panels ---

@Composable
private fun MediaPanel(onAddMedia: () -> Unit, onClose: () -> Unit) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("Add Video & Image Clips", color = VynoxTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Select media to append to the end of your timeline", color = VynoxTextMuted, fontSize = 11.sp)
        }
        Row {
            Button(
                onClick = onAddMedia,
                colors = ButtonDefaults.buttonColors(containerColor = VynoxPurple),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Select Files", fontSize = 12.sp)
            }
            IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = VynoxTextMuted)
            }
        }
    }
}

@Composable
private fun AudioPanel(
    isRecording: Boolean,
    onImportMusic: () -> Unit,
    onStartRecord: () -> Unit,
    onStopRecord: () -> Unit,
    onClose: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text("Audio & Voice-over", color = VynoxTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("Add background music or record speech", color = VynoxTextMuted, fontSize = 11.sp)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Button(
                onClick = onImportMusic,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7)),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(Icons.Default.MusicNote, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("Import Track", fontSize = 12.sp)
            }
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = { if (isRecording) onStopRecord() else onStartRecord() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRecording) Color(0xFFF43F5E) else Color(0xFF0F766E)
                ),
                shape = RoundedCornerShape(8.dp)
            ) {
                Icon(
                    if (isRecording) Icons.Default.MicOff else Icons.Default.Mic,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isRecording) "Stop Mic" else "Record Voice", fontSize = 12.sp)
            }
            IconButton(onClick = onClose, modifier = Modifier.size(32.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = VynoxTextMuted)
            }
        }
    }
}

@Composable
private fun TextPanel(
    onAddText: (String, Long, Float, TextAnimation) -> Unit,
    onClose: () -> Unit
) {
    var textInput by remember { mutableStateOf("New Title") }
    var selectedColor by remember { mutableStateOf(0xFFFFFFFF) }
    var selectedAnim by remember { mutableStateOf(TextAnimation.FADE_IN) }

    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Add Text & Subtitles", color = VynoxTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = VynoxTextMuted)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = textInput,
                onValueChange = { textInput = it },
                label = { Text("Text content (EN / हिन्दी)") },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = VynoxPurple,
                    focusedTextColor = VynoxTextPrimary,
                    unfocusedTextColor = VynoxTextPrimary
                ),
                modifier = Modifier.weight(1f)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Button(
                onClick = {
                    onAddText(textInput, selectedColor, 28f, selectedAnim)
                },
                colors = ButtonDefaults.buttonColors(containerColor = VynoxPurple),
                shape = RoundedCornerShape(8.dp)
            ) {
                Text("Add Text")
            }
        }
    }
}

@Composable
private fun EffectsPanel(
    selectedClipIndex: Int?,
    onSelectFilter: (FilterEffect) -> Unit,
    onClose: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Cinematic Color Filters", color = VynoxTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = VynoxTextMuted)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterEffect.values().forEach { filter ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF242236))
                        .border(1.dp, VynoxBorder, RoundedCornerShape(8.dp))
                        .clickable { onSelectFilter(filter) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(text = filter.displayName, color = VynoxElectricBlue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun TransitionsPanel(
    selectedClipIndex: Int?,
    onSelectTransition: (TransitionType) -> Unit,
    onClose: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Transitions Between Clips", color = VynoxTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = VynoxTextMuted)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            TransitionType.values().forEach { type ->
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF242236))
                        .border(1.dp, VynoxBorder, RoundedCornerShape(8.dp))
                        .clickable { onSelectTransition(type) }
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Text(text = type.displayName, color = VynoxPurpleGlow, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                }
            }
        }
    }
}

@Composable
private fun CanvasPanel(
    currentRatio: AspectRatio,
    onSelectRatio: (AspectRatio) -> Unit,
    onSelectBgColor: (Long) -> Unit,
    onClose: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Canvas Aspect Ratio & Background", color = VynoxTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = VynoxTextMuted)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            AspectRatio.values().forEach { ratio ->
                val isSelected = currentRatio == ratio
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) VynoxPurple.copy(alpha = 0.3f) else Color(0xFF242236))
                        .border(1.dp, if (isSelected) VynoxElectricBlue else VynoxBorder, RoundedCornerShape(8.dp))
                        .clickable { onSelectRatio(ratio) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = ratio.label.split(" ").first(),
                        color = if (isSelected) VynoxElectricBlue else VynoxTextPrimary,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun AdjustPanel(
    adjustments: ColorAdjustments,
    onUpdate: (ColorAdjustments) -> Unit,
    onReset: () -> Unit,
    onClose: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Color Grading & Adjustments", color = VynoxTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Row {
                TextButton(onClick = onReset) {
                    Text("Reset", color = VynoxElectricBlue, fontSize = 12.sp)
                }
                IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                    Icon(Icons.Default.Close, contentDescription = "Close", tint = VynoxTextMuted)
                }
            }
        }
        // Brightness slider
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Brightness", color = VynoxTextSecondary, fontSize = 12.sp, modifier = Modifier.width(80.dp))
            Slider(
                value = adjustments.brightness,
                onValueChange = { onUpdate(adjustments.copy(brightness = it)) },
                valueRange = -0.5f..0.5f,
                colors = SliderDefaults.colors(thumbColor = VynoxElectricBlue, activeTrackColor = VynoxPurple),
                modifier = Modifier.weight(1f)
            )
        }
        // Contrast slider
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Contrast", color = VynoxTextSecondary, fontSize = 12.sp, modifier = Modifier.width(80.dp))
            Slider(
                value = adjustments.contrast,
                onValueChange = { onUpdate(adjustments.copy(contrast = it)) },
                valueRange = 0.5f..1.5f,
                colors = SliderDefaults.colors(thumbColor = VynoxElectricBlue, activeTrackColor = VynoxPurple),
                modifier = Modifier.weight(1f)
            )
        }
    }
}

@Composable
private fun SpeedPanel(
    selectedClipIndex: Int?,
    currentSpeed: Float,
    onSetSpeed: (Float) -> Unit,
    onClose: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Speed Control (Slow-Mo / Fast)", color = VynoxTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = VynoxTextMuted)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            listOf(0.25f, 0.5f, 1.0f, 1.5f, 2.0f, 4.0f).forEach { speed ->
                val isSelected = (currentSpeed - speed) in -0.05f..0.05f
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) VynoxPurple else Color(0xFF242236))
                        .clickable { onSetSpeed(speed) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${speed}x",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun LayersPanel(
    project: com.example.model.VynoxProject?,
    onClose: () -> Unit
) {
    Column {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Timeline Track Layers", color = VynoxTextPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            IconButton(onClick = onClose, modifier = Modifier.size(28.dp)) {
                Icon(Icons.Default.Close, contentDescription = "Close", tint = VynoxTextMuted)
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text("• Track 1: ${project?.textOverlays?.size ?: 0} Text Overlays", color = VynoxPurpleGlow, fontSize = 12.sp)
        Text("• Track 2: ${project?.videoClips?.size ?: 0} Video/Image Clips", color = VynoxElectricBlue, fontSize = 12.sp)
        Text("• Track 3: ${project?.audioClips?.size ?: 0} Audio & Voice Tracks", color = Color(0xFF10B981), fontSize = 12.sp)
    }
}
