package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.AspectRatio
import com.example.ui.theme.VynoxBorder
import com.example.ui.theme.VynoxElectricBlue
import com.example.ui.theme.VynoxPurple
import com.example.ui.theme.VynoxTextMuted
import com.example.ui.theme.VynoxTextPrimary
import com.example.ui.theme.VynoxTextSecondary

@Composable
fun NewProjectDialog(
    onDismiss: () -> Unit,
    onSelectMedia: (name: String, ratio: AspectRatio) -> Unit,
    onStartBlank: (name: String, ratio: AspectRatio) -> Unit,
    onStartSample: (ratio: AspectRatio) -> Unit
) {
    var projectName by remember { mutableStateOf("New Project") }
    var selectedRatio by remember { mutableStateOf(AspectRatio.RATIO_9_16) }

    Dialog(onDismissRequest = onDismiss) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(20.dp))
                .background(Color(0xFF161522))
                .border(1.dp, VynoxBorder, RoundedCornerShape(20.dp))
                .padding(20.dp)
                .testTag("new_project_dialog")
        ) {
            Column {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "New Project",
                            color = VynoxTextPrimary,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Set aspect ratio & media source",
                            color = VynoxTextMuted,
                            fontSize = 12.sp
                        )
                    }

                    IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = VynoxTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Project Name Input
                OutlinedTextField(
                    value = projectName,
                    onValueChange = { projectName = it },
                    label = { Text("Project Name") },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = VynoxPurple,
                        unfocusedBorderColor = VynoxBorder,
                        focusedLabelColor = VynoxPurple,
                        unfocusedLabelColor = VynoxTextMuted,
                        focusedTextColor = VynoxTextPrimary,
                        unfocusedTextColor = VynoxTextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("project_name_input")
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Aspect Ratio Selector
                Text(
                    text = "Aspect Ratio",
                    color = VynoxTextSecondary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AspectRatio.values().forEach { ratio ->
                        val isSelected = selectedRatio == ratio
                        Box(
                            modifier = Modifier
                                .weight(1f)
                                .clip(RoundedCornerShape(10.dp))
                                .background(if (isSelected) VynoxPurple.copy(alpha = 0.2f) else Color(0xFF1E1C2C))
                                .border(
                                    1.5.dp,
                                    if (isSelected) VynoxPurple else VynoxBorder,
                                    RoundedCornerShape(10.dp)
                                )
                                .clickable { selectedRatio = ratio }
                                .padding(vertical = 10.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Text(
                                    text = when (ratio) {
                                        AspectRatio.RATIO_9_16 -> "9:16"
                                        AspectRatio.RATIO_16_9 -> "16:9"
                                        AspectRatio.RATIO_1_1 -> "1:1"
                                        AspectRatio.RATIO_4_5 -> "4:5"
                                    },
                                    color = if (isSelected) VynoxElectricBlue else VynoxTextPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = when (ratio) {
                                        AspectRatio.RATIO_9_16 -> "Vertical"
                                        AspectRatio.RATIO_16_9 -> "Landscape"
                                        AspectRatio.RATIO_1_1 -> "Square"
                                        AspectRatio.RATIO_4_5 -> "Portrait"
                                    },
                                    color = VynoxTextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action 1: Select Media from Device
                Button(
                    onClick = { onSelectMedia(projectName, selectedRatio) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .background(
                            Brush.horizontalGradient(listOf(VynoxPurple, VynoxElectricBlue)),
                            RoundedCornerShape(12.dp)
                        )
                        .testTag("choose_media_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AddPhotoAlternate,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Choose Videos & Photos",
                        color = Color.White,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action 2: Starter Demo Project
                Button(
                    onClick = { onStartSample(selectedRatio) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF222033)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .border(1.dp, VynoxBorder, RoundedCornerShape(12.dp))
                        .testTag("sample_starter_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = VynoxElectricBlue,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Start with Demo Clips",
                        color = VynoxElectricBlue,
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 14.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Action 3: Blank Timeline
                Button(
                    onClick = { onStartBlank(projectName, selectedRatio) },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Transparent),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .border(1.dp, VynoxBorder.copy(alpha = 0.6f), RoundedCornerShape(12.dp))
                        .testTag("blank_timeline_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Edit,
                        contentDescription = null,
                        tint = VynoxTextSecondary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Blank Timeline",
                        color = VynoxTextSecondary,
                        fontWeight = FontWeight.Medium,
                        fontSize = 14.sp
                    )
                }
            }
        }
    }
}
