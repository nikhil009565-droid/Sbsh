package com.example.data

import android.content.Context
import com.example.model.AspectRatio
import com.example.model.AudioClip
import com.example.model.CanvasFitMode
import com.example.model.ClipTransition
import com.example.model.ColorAdjustments
import com.example.model.FilterEffect
import com.example.model.ImageOverlay
import com.example.model.TextAnimation
import com.example.model.TextOverlay
import com.example.model.TransitionType
import com.example.model.VideoClip
import com.example.model.VynoxProject
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

class ProjectRepository(private val context: Context) {
    private val dao = VynoxDatabase.getInstance(context).projectDao()

    val allProjects: Flow<List<VynoxProject>> = dao.getAllProjects().map { entities ->
        entities.mapNotNull { deserializeProject(it.projectJson) }
    }

    suspend fun getProject(id: String): VynoxProject? {
        val entity = dao.getProjectById(id) ?: return null
        return deserializeProject(entity.projectJson)
    }

    suspend fun saveProject(project: VynoxProject) {
        val json = serializeProject(project)
        val entity = ProjectEntity(
            id = project.id,
            name = project.name,
            createdAt = project.createdAt,
            lastModifiedAt = System.currentTimeMillis(),
            aspectRatioName = project.aspectRatio.name,
            durationMs = project.totalDurationMs,
            thumbnailUri = project.thumbnailUri ?: project.videoClips.firstOrNull()?.uri,
            projectJson = json
        )
        dao.insertOrUpdate(entity)
    }

    suspend fun deleteProject(id: String) {
        dao.deleteProject(id)
    }

    suspend fun duplicateProject(project: VynoxProject): VynoxProject {
        val duplicated = project.copy(
            id = UUID.randomUUID().toString(),
            name = "${project.name} (Copy)",
            createdAt = System.currentTimeMillis(),
            lastModifiedAt = System.currentTimeMillis()
        )
        saveProject(duplicated)
        return duplicated
    }

    // --- JSON Serialization ---
    fun serializeProject(p: VynoxProject): String {
        val root = JSONObject()
        root.put("id", p.id)
        root.put("name", p.name)
        root.put("createdAt", p.createdAt)
        root.put("lastModifiedAt", p.lastModifiedAt)
        root.put("aspectRatio", p.aspectRatio.name)
        root.put("canvasBgColorHex", p.canvasBgColorHex)
        root.put("canvasBlurBg", p.canvasBlurBg)
        root.put("fitMode", p.fitMode.name)
        root.put("thumbnailUri", p.thumbnailUri ?: "")

        // Adjustments
        val adjObj = JSONObject().apply {
            put("brightness", p.colorAdjustments.brightness.toDouble())
            put("contrast", p.colorAdjustments.contrast.toDouble())
            put("saturation", p.colorAdjustments.saturation.toDouble())
            put("temperature", p.colorAdjustments.temperature.toDouble())
            put("tint", p.colorAdjustments.tint.toDouble())
            put("vignette", p.colorAdjustments.vignette.toDouble())
        }
        root.put("colorAdjustments", adjObj)

        // Video clips
        val clipsArr = JSONArray()
        for (c in p.videoClips) {
            val cObj = JSONObject().apply {
                put("id", c.id)
                put("uri", c.uri)
                put("name", c.name)
                put("isImage", c.isImage)
                put("sourceDurationMs", c.sourceDurationMs)
                put("trimStartMs", c.trimStartMs)
                put("trimEndMs", c.trimEndMs)
                put("speed", c.speed.toDouble())
                put("volume", c.volume.toDouble())
                put("rotationDegrees", c.rotationDegrees)
                put("flipH", c.flipH)
                put("flipV", c.flipV)
                put("filterEffect", c.filterEffect.name)
                put("opacity", c.opacity.toDouble())
                put("chromaKeyEnabled", c.chromaKeyEnabled)
                put("chromaKeyColorHex", c.chromaKeyColorHex)
            }
            clipsArr.put(cObj)
        }
        root.put("videoClips", clipsArr)

        // Audio clips
        val audioArr = JSONArray()
        for (a in p.audioClips) {
            val aObj = JSONObject().apply {
                put("id", a.id)
                put("uri", a.uri)
                put("title", a.title)
                put("startTimelineMs", a.startTimelineMs)
                put("trimStartMs", a.trimStartMs)
                put("durationMs", a.durationMs)
                put("volume", a.volume.toDouble())
                put("fadeInMs", a.fadeInMs)
                put("fadeOutMs", a.fadeOutMs)
                put("isVoiceOver", a.isVoiceOver)
            }
            audioArr.put(aObj)
        }
        root.put("audioClips", audioArr)

        // Text overlays
        val textArr = JSONArray()
        for (t in p.textOverlays) {
            val tObj = JSONObject().apply {
                put("id", t.id)
                put("text", t.text)
                put("fontSizeSp", t.fontSizeSp.toDouble())
                put("textColorHex", t.textColorHex)
                put("outlineColorHex", t.outlineColorHex)
                put("bgColorHex", t.bgColorHex)
                put("hasBackground", t.hasBackground)
                put("hasOutline", t.hasOutline)
                put("fontFamilyName", t.fontFamilyName)
                put("xPercent", t.xPercent.toDouble())
                put("yPercent", t.yPercent.toDouble())
                put("startTimelineMs", t.startTimelineMs)
                put("endTimelineMs", t.endTimelineMs)
                put("animation", t.animation.name)
            }
            textArr.put(tObj)
        }
        root.put("textOverlays", textArr)

        // Image overlays
        val imgArr = JSONArray()
        for (im in p.imageOverlays) {
            val imObj = JSONObject().apply {
                put("id", im.id)
                put("uri", im.uri)
                put("xPercent", im.xPercent.toDouble())
                put("yPercent", im.yPercent.toDouble())
                put("scale", im.scale.toDouble())
                put("rotation", im.rotation.toDouble())
                put("opacity", im.opacity.toDouble())
                put("startTimelineMs", im.startTimelineMs)
                put("endTimelineMs", im.endTimelineMs)
            }
            imgArr.put(imObj)
        }
        root.put("imageOverlays", imgArr)

        // Transitions
        val transArr = JSONArray()
        for (tr in p.transitions) {
            val trObj = JSONObject().apply {
                put("clipIndex", tr.clipIndex)
                put("type", tr.type.name)
                put("durationMs", tr.durationMs)
            }
            transArr.put(trObj)
        }
        root.put("transitions", transArr)

        return root.toString()
    }

    fun deserializeProject(jsonStr: String): VynoxProject? {
        return try {
            val root = JSONObject(jsonStr)
            val id = root.optString("id", UUID.randomUUID().toString())
            val name = root.optString("name", "Untitled")
            val createdAt = root.optLong("createdAt", System.currentTimeMillis())
            val lastModifiedAt = root.optLong("lastModifiedAt", System.currentTimeMillis())
            val aspectRatio = try {
                AspectRatio.valueOf(root.optString("aspectRatio", AspectRatio.RATIO_9_16.name))
            } catch (e: Exception) {
                AspectRatio.RATIO_9_16
            }
            val canvasBgColorHex = root.optLong("canvasBgColorHex", 0xFF000000)
            val canvasBlurBg = root.optBoolean("canvasBlurBg", false)
            val fitMode = try {
                CanvasFitMode.valueOf(root.optString("fitMode", CanvasFitMode.FIT.name))
            } catch (e: Exception) {
                CanvasFitMode.FIT
            }
            val thumb = root.optString("thumbnailUri", "").takeIf { it.isNotEmpty() }

            val adjObj = root.optJSONObject("colorAdjustments")
            val adjustments = if (adjObj != null) {
                ColorAdjustments(
                    brightness = adjObj.optDouble("brightness", 0.0).toFloat(),
                    contrast = adjObj.optDouble("contrast", 1.0).toFloat(),
                    saturation = adjObj.optDouble("saturation", 1.0).toFloat(),
                    temperature = adjObj.optDouble("temperature", 0.0).toFloat(),
                    tint = adjObj.optDouble("tint", 0.0).toFloat(),
                    vignette = adjObj.optDouble("vignette", 0.0).toFloat()
                )
            } else ColorAdjustments()

            val clipsArr = root.optJSONArray("videoClips") ?: JSONArray()
            val videoClips = mutableListOf<VideoClip>()
            for (i in 0 until clipsArr.length()) {
                val c = clipsArr.getJSONObject(i)
                val filter = try {
                    FilterEffect.valueOf(c.optString("filterEffect", FilterEffect.NONE.name))
                } catch (e: Exception) {
                    FilterEffect.NONE
                }
                videoClips.add(
                    VideoClip(
                        id = c.optString("id", UUID.randomUUID().toString()),
                        uri = c.optString("uri"),
                        name = c.optString("name", "Clip ${i + 1}"),
                        isImage = c.optBoolean("isImage", false),
                        sourceDurationMs = c.optLong("sourceDurationMs", 5000L),
                        trimStartMs = c.optLong("trimStartMs", 0L),
                        trimEndMs = c.optLong("trimEndMs", 5000L),
                        speed = c.optDouble("speed", 1.0).toFloat(),
                        volume = c.optDouble("volume", 1.0).toFloat(),
                        rotationDegrees = c.optInt("rotationDegrees", 0),
                        flipH = c.optBoolean("flipH", false),
                        flipV = c.optBoolean("flipV", false),
                        filterEffect = filter,
                        opacity = c.optDouble("opacity", 1.0).toFloat(),
                        chromaKeyEnabled = c.optBoolean("chromaKeyEnabled", false),
                        chromaKeyColorHex = c.optLong("chromaKeyColorHex", 0xFF00FF00)
                    )
                )
            }

            val audioArr = root.optJSONArray("audioClips") ?: JSONArray()
            val audioClips = mutableListOf<AudioClip>()
            for (i in 0 until audioArr.length()) {
                val a = audioArr.getJSONObject(i)
                audioClips.add(
                    AudioClip(
                        id = a.optString("id", UUID.randomUUID().toString()),
                        uri = a.optString("uri"),
                        title = a.optString("title", "Audio"),
                        startTimelineMs = a.optLong("startTimelineMs", 0L),
                        trimStartMs = a.optLong("trimStartMs", 0L),
                        durationMs = a.optLong("durationMs", 5000L),
                        volume = a.optDouble("volume", 1.0).toFloat(),
                        fadeInMs = a.optLong("fadeInMs", 0L),
                        fadeOutMs = a.optLong("fadeOutMs", 0L),
                        isVoiceOver = a.optBoolean("isVoiceOver", false)
                    )
                )
            }

            val textArr = root.optJSONArray("textOverlays") ?: JSONArray()
            val textOverlays = mutableListOf<TextOverlay>()
            for (i in 0 until textArr.length()) {
                val t = textArr.getJSONObject(i)
                val anim = try {
                    TextAnimation.valueOf(t.optString("animation", TextAnimation.NONE.name))
                } catch (e: Exception) {
                    TextAnimation.NONE
                }
                textOverlays.add(
                    TextOverlay(
                        id = t.optString("id", UUID.randomUUID().toString()),
                        text = t.optString("text", "Text"),
                        fontSizeSp = t.optDouble("fontSizeSp", 24.0).toFloat(),
                        textColorHex = t.optLong("textColorHex", 0xFFFFFFFF),
                        outlineColorHex = t.optLong("outlineColorHex", 0xFF000000),
                        bgColorHex = t.optLong("bgColorHex", 0x00000000),
                        hasBackground = t.optBoolean("hasBackground", false),
                        hasOutline = t.optBoolean("hasOutline", true),
                        fontFamilyName = t.optString("fontFamilyName", "Default"),
                        xPercent = t.optDouble("xPercent", 0.5).toFloat(),
                        yPercent = t.optDouble("yPercent", 0.5).toFloat(),
                        startTimelineMs = t.optLong("startTimelineMs", 0L),
                        endTimelineMs = t.optLong("endTimelineMs", 4000L),
                        animation = anim
                    )
                )
            }

            val imgArr = root.optJSONArray("imageOverlays") ?: JSONArray()
            val imageOverlays = mutableListOf<ImageOverlay>()
            for (i in 0 until imgArr.length()) {
                val im = imgArr.getJSONObject(i)
                imageOverlays.add(
                    ImageOverlay(
                        id = im.optString("id", UUID.randomUUID().toString()),
                        uri = im.optString("uri"),
                        xPercent = im.optDouble("xPercent", 0.5).toFloat(),
                        yPercent = im.optDouble("yPercent", 0.5).toFloat(),
                        scale = im.optDouble("scale", 1.0).toFloat(),
                        rotation = im.optDouble("rotation", 0.0).toFloat(),
                        opacity = im.optDouble("opacity", 1.0).toFloat(),
                        startTimelineMs = im.optLong("startTimelineMs", 0L),
                        endTimelineMs = im.optLong("endTimelineMs", 4000L)
                    )
                )
            }

            val transArr = root.optJSONArray("transitions") ?: JSONArray()
            val transitions = mutableListOf<ClipTransition>()
            for (i in 0 until transArr.length()) {
                val tr = transArr.getJSONObject(i)
                val type = try {
                    TransitionType.valueOf(tr.optString("type", TransitionType.NONE.name))
                } catch (e: Exception) {
                    TransitionType.NONE
                }
                transitions.add(
                    ClipTransition(
                        clipIndex = tr.optInt("clipIndex", 0),
                        type = type,
                        durationMs = tr.optLong("durationMs", 500L)
                    )
                )
            }

            VynoxProject(
                id = id,
                name = name,
                createdAt = createdAt,
                lastModifiedAt = lastModifiedAt,
                aspectRatio = aspectRatio,
                canvasBgColorHex = canvasBgColorHex,
                canvasBlurBg = canvasBlurBg,
                fitMode = fitMode,
                videoClips = videoClips,
                audioClips = audioClips,
                textOverlays = textOverlays,
                imageOverlays = imageOverlays,
                transitions = transitions,
                colorAdjustments = adjustments,
                thumbnailUri = thumb
            )
        } catch (e: Exception) {
            e.printStackTrace()
            null
        }
    }
}
